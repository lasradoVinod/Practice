echo "Hello world- $(hostname)" > /usr/share/nginx/html/index.html
